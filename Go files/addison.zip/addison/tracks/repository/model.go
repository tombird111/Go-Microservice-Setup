package repository

type Cell struct {
        Id      string
        Audio   string
}