package service

type MusicInfo struct {
        Audio   string
}